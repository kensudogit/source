/**
 * Spring JDBC row mapping extensions.
 */
package org.springframework.jdbc.core;

