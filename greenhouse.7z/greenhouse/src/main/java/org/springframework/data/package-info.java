/**
 * Spring Data extensions for FileStorage; supports S3 and local file storage.
 */
package org.springframework.data;

