/**
 * Action framework for modeling member activity.
 */
package com.springsource.greenhouse.activity.action;

