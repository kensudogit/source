/**
 * Badge system that rewards members for participating in the community.
 */
package com.springsource.greenhouse.activity.badge;

