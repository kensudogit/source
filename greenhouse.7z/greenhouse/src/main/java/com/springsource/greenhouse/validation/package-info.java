/**
 * Data validation extensions.
 */
package com.springsource.greenhouse.validation;