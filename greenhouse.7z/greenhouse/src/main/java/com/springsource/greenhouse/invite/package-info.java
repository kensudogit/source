/**
 * Infrastructure for sending and accepting invites to join our community.
 */
package com.springsource.greenhouse.invite;

