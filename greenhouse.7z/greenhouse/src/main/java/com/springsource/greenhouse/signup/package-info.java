/**
 * Functionality for registering new member accounts.
 */
package com.springsource.greenhouse.signup;

