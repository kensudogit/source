/**
 * For sending invites to email contacts.
 */
package com.springsource.greenhouse.invite.mail;

