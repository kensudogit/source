/**
 * Greenhouse-specific connection support classes
 */
package com.springsource.greenhouse.connect;

