/**
 * Spring Framework extensions that aid in configuring the Greenhouse application.
 */
package com.springsource.greenhouse.config;

